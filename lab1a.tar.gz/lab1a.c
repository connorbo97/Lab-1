//NAME:Connor Borden
//EMAIL:connorbo97@g.ucla.edu
//ID:004603469

#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <getopt.h>
#include <string.h>
#include <errno.h>
#include <poll.h>
#include <sys/types.h>
#include <sys/wait.h>
//#include <io.h>

int sFlag = 0; //shell enabled

int pipeP2C[2];
int pipeC2P[2];
char* buf;
int bufferSize = 8;
pid_t childPID;
struct pollfd pollArr[2];
//pid_t parentPID;
int pipeClosed = 0;

void restoreTerminal()
{
	struct termios restorer;
	tcgetattr(0, &restorer);
	restorer.c_iflag = 1280;
	restorer.c_lflag = 35387;
	restorer.c_oflag = 5;
	tcsetattr(0, TCSANOW, &restorer);
}

void signalOutput(int signal)
{
	
//			char buffer[6] = "p";
//			write(1,buffer, strlen(&buffer));
	restoreTerminal();
	if(signal == SIGPIPE)
	{
		
		int exitStatus;
		waitpid(childPID, &exitStatus,0);
					
		//if(WIFSIGNALED(exitStatus))
		//{
		//	fprintf(stderr, "ended by signal, %d %d", exitStatus, &exitStatus);
		//}
		//if(WIFEXITED(exitStatus))
		//{					
		//f(WIFSIGNALED(exitStatus));
		int low = WEXITSTATUS(exitStatus);
		int high;
		if(WIFSIGNALED(exitStatus))
		{
			high = WTERMSIG(exitStatus);	
		}
		else
		{
			high = 0;
		}
		fprintf(stderr, "SHELL EXIT SIGNAL=%d  STATUS=%d", high, low);
		exit(0);		
	}
	else if(sFlag && signal == SIGINT)
	{
		fprintf(stdout, "SIGINT recieved. Killing child");
		exit(1);
		
	}
	else
	{
		exit(2);
	}
	//exit(1);
}

void passBytes(int in, int out)
{
	int readSuccess = read(in, buf, 1024);
	int readCount = 0;
	while(readSuccess > readCount)
	{
		if(*(buf+readCount) == '\004')
		{
			if(sFlag)
			{
				if(in == 0)
				{
					close(pipeP2C[1]);
					//close(pipeC2P[0]);
					pipeClosed = 1;
					break;
				}
				
			}
			else
			{
				restoreTerminal();
				exit(0);
			}
		}
		else if(*(buf+readCount) == '\003' && sFlag)
		{
			pipeClosed = 2;
			kill(childPID, SIGINT);
			close(pipeP2C[0]);
			close(pipeP2C[1]);
			close(pipeC2P[0]);
			close(pipeC2P[1]);
			//restoreTerminal();
			//exit(0);
			break;
		}
		else if((*(buf+readCount) == '\r' || *(buf+readCount) == '\n'))
		{
			char crlf[2];
			crlf[0] = '\r';
			crlf[1] = '\n';
			//*buf = '\015';
			//write(out, buf, 1);
			//*buf = '\012';
					
			if(in == 0)
			{
				if(write(out, &crlf, 2) == -1)
				{	
					fprintf(stderr, "Failed to write bits to %d: %s",out, strerror(errno));
					exit(1);
				}
			}
			if(in == 0 && sFlag && pipeClosed == 0)
			{
			//	*buf = '\015';
			//	write(pipeP2C[1], buf, 1);
			//	*buf = '\012';
				crlf[0] = '\n';
				
				if(write(pipeP2C[1], &crlf, 1) == -1)
				{
					fprintf(stderr, "Failed to write bits to pipe: %s", strerror(errno));
					exit(1);
				}
				break;
			}
			else if(in == pipeC2P[0])
			{
				
//				crlf[0] = '\n';
				
				if(write(out, &crlf, 2) == -1)
				{
					fprintf(stderr, "Failed to write bits to pipe: %s", strerror(errno));
					exit(1);
				}
				
			}
		
		}
		else
		{
			if(in == 0 && sFlag && pipeClosed == 0)
			{
				if(write(pipeP2C[1], buf, 1) == -1)
				{
					fprintf(stderr, "Failed to write bits to pipe: %s", strerror(errno));
					exit(1);
				}
			}
			if(write(out, buf + readCount, 1) == -1)
			{
				fprintf(stderr, "Failed to write bits to %d: %s",out, strerror(errno));
				exit(1);
			}
		}
		readCount++;
		if(readSuccess == readCount && in == 0)
		{
			readSuccess = read(in, buf, 1);
			readCount = 0;
		}
		if(readSuccess == -1)
		{
			fprintf(stderr, "Failure to read bits from %d: %s", in, strerror(errno));
			exit(1);
		}
	}
	if(readSuccess == -1)
	{
		fprintf(stderr, "Failure to read bits from %d: %s", in, strerror(errno));
		exit(1);
	}
}

int main(int argc, char** argv)
{
	//if(argv[1] != 's')
	//{
	//	fprintf(stderr, "Too many arguments %s %s %s", argv[0], argv[1], argv[2]);

	//	exit(1);
	//}
	buf = (char*)malloc(sizeof(char) * 1024);
	if(*buf == -1)
	{
		fprintf(stderr, "Error while using malloc\n");
		exit(1);
	}
	if(!isatty(0))
	{
		fprintf(stderr, "Not a terminal \n");
		exit(1);
	}
	static struct option args[] =
	{
		{"shell", no_argument, 0, 's'},
		{0,0,0,0}	
	
	};
	//if(!isatty(0))
	//{
//		fprintf(stderr, "Invalid input"
//	}
	int option = 0;

	while((option = getopt_long(argc,argv, "s", args, NULL)) != -1)
	{
		switch(option)
		{
			case 's':
				signal(SIGINT, signalOutput);
				sFlag = 1;
				break;
			default:
				fprintf(stderr, "Only accepted flag is --shell or -s for short");
				//restoreTerminal();
				exit(1);
		}
	}
	
	struct termios a;
	if(tcgetattr(0, &a) < 0)
	{	
		fprintf(stderr, "errno: %d\n", errno);
		fprintf(stderr, "Failed while getting terminal: %s\n", strerror(errno));
		//exit(1);
	}
	a.c_iflag = ISTRIP;
	a.c_lflag = 0;
	a.c_oflag = 0;
	//printf("iflag %d oflag %d cflag %d lflag %d \n", a.c_iflag, a.c_oflag, a.c_cflag, a.c_lflag);
	
	if(tcsetattr(0,TCSAFLUSH, &a) < 0)
	{
		fprintf(stderr, "failed while setting terminal attributes, errno: %d str: %s\n", errno, strerror(errno));
		exit(1);
	}
	if(sFlag)
	{
	//	signal(SIGTTIN, signalOutput);
		if(pipe(pipeP2C) == -1)
		{
			fprintf(stderr, "Fail while calling pipe()");
			exit(1);
		}
		if(pipe(pipeC2P) == -1)
		{
			fprintf(stderr, "Fail while calling pipe()");
			exit(1);
		}
		
		pollArr[0] = (struct pollfd){.fd = 0, .events = POLLIN};
		pollArr[1] = (struct pollfd) {.fd = pipeC2P[0], .events = POLLIN};
		childPID = fork();
		if(childPID == -1)
		{
			
			fprintf(stderr, "Failed to fork");
			exit(1);
		}
		else if(childPID == 0)	//child
		{
			
			close(pipeP2C[1]);		//close write of parent to child pipe
			close(pipeC2P[0]);		//close read of child to parent pipe
			close(0);	
			dup(pipeP2C[0]);
			close(1);
			dup(pipeC2P[1]);
			close(2);
			dup(pipeC2P[1]);
			close(pipeP2C[0]);
			close(pipeP2C[1]);
			char *bashArgs[] = {"/bin/bash", NULL};
			if(execvp("/bin/bash",bashArgs) == -1)
			{
				fprintf(stderr, "Couldn't execute /bin/bash: %s", strerror(errno));
				exit(1);
			}
			
		}	
 		else					//parent
		{
			close(pipeP2C[0]);
			close(pipeC2P[1]);
			//pass from shell program to output			
			//wait(childPID);
			poll(pollArr, 2, 0);
			while(1)
			{
				if(pipeClosed > 0)
				{
					
					int exitStatus;
					waitpid(childPID, &exitStatus,0);
					
					//if(WIFSIGNALED(exitStatus))
					//{
					//	fprintf(stderr, "ended by signal, %d %d", exitStatus, &exitStatus);
					//}
					//if(WIFEXITED(exitStatus))
					//{					
					//f(WIFSIGNALED(exitStatus));
					int low = WEXITSTATUS(exitStatus);
					int high;
					if(WIFSIGNALED(exitStatus))
					{
						high = WTERMSIG(exitStatus);	
					}
					else
					{
						high = 0;
					}
					fprintf(stderr, "SHELL EXIT SIGNAL=%d  STATUS=%d", high, low);
					
					restoreTerminal();
					exit(0);
									
				}
				if(pollArr[0].revents == POLLIN && pipeClosed != 2)
				{
					passBytes(0,1);
					//write(1,buffer, strlen(&buffer));
					if(pipeClosed != 2)
					{
						passBytes(pipeC2P[0], 1);//passBytes(pipeC2P[0], 1);
					}
					
				}
				if(pollArr[1].revents == POLLHUP || pollArr[1].revents == POLLERR)
				{
					close(pipeP2C[0]);
					close(pipeP2C[1]);
					close(pipeC2P[0]);
					close(pipeC2P[1]);
					
					int exitStatus;
					waitpid(childPID, &exitStatus,0);
					
					//if(WIFSIGNALED(exitStatus))
					//{
					//	fprintf(stderr, "ended by signal, %d %d", exitStatus, &exitStatus);
					//}
					//if(WIFEXITED(exitStatus))
					//{					
					//f(WIFSIGNALED(exitStatus));
					int low = WEXITSTATUS(exitStatus);
					int high;
					if(WIFSIGNALED(exitStatus))
					{
						high = WTERMSIG(exitStatus);	
					}
					else
					{
						high = 0;
					}
					fprintf(stderr, "SHELL EXIT SIGNAL=%d  STATUS=%d", high, low);
					restoreTerminal();
					exit(0);
				}
				poll(pollArr,2,0);
			}
		}

			
	}
	while(1)
	{
		passBytes(0,1);
	}
	restoreTerminal();
	exit(0);
	
}

//NAME:Connor Borden
//EMAIL:connorbo97@g.ucla.edu
//ID:004603469

#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <getopt.h>
#include <string.h>
#include <errno.h>
#include <poll.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include<netdb.h>
#include<netinet/in.h>
//#include <io.h>
#include <mcrypt.h>
#include <fcntl.h>

int pipeP2C[2];
int pipeC2P[2];
char* buf;
int bufferSize = 8;
pid_t childPID;
struct pollfd pollArr[2];
//pid_t parentPID;
int socketfd;
int portNum;
int connection;
int clientExit;
int shellExit;
int encryptFlag = 0;
MCRYPT crypt1;
MCRYPT crypt2;
char* iv = "AAAAAAAAAAAAAAAA";
char* key;
int keyLen = 16;
int keyfd;


void signalOutput(int signal)
{
	
	if(signal == SIGPIPE)
	{
		int exitStatus;
		waitpid(childPID, &exitStatus,0);
					
		int low = WEXITSTATUS(exitStatus);
		int high;
		if(WIFSIGNALED(exitStatus))
		{
			high = WTERMSIG(exitStatus);	
		}
		else
		{
			high = 0;
		}
		fprintf(stderr, "SHELL EXIT SIGNAL=%d  STATUS=%d", high, low);
		//fprintf(stderr, "sigpipe");
		exit(0);		
		
	}
	else if(signal == SIGINT)
	{
		int exitStatus;
		waitpid(childPID, &exitStatus,0);
					
		int low = WEXITSTATUS(exitStatus);
		int high;
		if(WIFSIGNALED(exitStatus))
		{
			high = WTERMSIG(exitStatus);	
		}
		else
		{
			high = 0;
		}
		fprintf(stderr, "SHELL EXIT SIGNAL=%d  STATUS=%d", high, low);
		//fprintf(stderr, "sigpipe");
		exit(0);		
	//	fprintf(stdout, "SIGINT recieved. Killing child");
		exit(1);
		
	}
	else
	{
		exit(2);
	}
}

void encrypt(char* buffer, int buffer_len, char* IV, char* key1, int key_len)
{
	crypt1 = mcrypt_module_open("twofish", NULL, "cfb", NULL);
	//int block = mcrypt_enc_get_block_size(crypt1);
	/*if(buffer_len % block != 0)
	{
		fprintf(stderr, "incompatible block size");
		exit(1);
	}*/
	
	mcrypt_generic_init(crypt1, key1, key_len, IV);
	mcrypt_generic(crypt1, buffer, buffer_len);
	mcrypt_generic_deinit(crypt1);
	mcrypt_module_close(crypt1);
}

void decrypt(void* buffer, int buffer_len, char* IV, char* key1, int key_len)
{
	crypt2 = mcrypt_module_open("twofish", NULL, "cfb", NULL);
	mcrypt_generic_init(crypt2, key1, key_len, IV);
	mdecrypt_generic(crypt2, buffer, buffer_len);
	mcrypt_generic_deinit(crypt2);
	mcrypt_module_close(crypt2);
}

void passBytes(int in, int out)
{
	int readSuccess = read(in, buf, 1024);
	int readCount = 0;
	while(readSuccess > readCount)
	{
		if(encryptFlag == 1 && in == connection)
		{
	
			decrypt(buf + readCount, 1, iv, key, keyLen);
		}
	
		if(*(buf+readCount) == '\004')
		{
			if(in == connection)
			{
		//		fprintf(stderr,"d received");
				close(pipeP2C[1]);
				close(socketfd);
				close(connection);
				kill(childPID, SIGTERM);
			}
			if(in == pipeC2P[0])
			{
				shellExit = 1;
			}
		}
		else if(*(buf+readCount) == '\003')
		{
			if(in == connection)
			{
				close(socketfd);
				close(connection);
				kill(childPID, SIGINT);
			}
			if(in == pipeC2P[0])
			{
				shellExit = 1;
			}
		}
		/*else if((*(buf+readCount) == '\r' || *(buf+readCount) == '\n'))
		{
			char crlf = '\n';
			if(encryptFlag == 1 && in == pipeC2P[0])
			{
				encrypt(&crlf, 1, iv, key, keyLen);
			}
			if(in == connection)
			{
				if(write(out, &crlf, 1) == -1)
				{	
					fprintf(stderr, "Failed to write bits to %d: %s",out, strerror(errno));
					exit(1);
				
				}
				if(write(pipeP2C[1], &crlf, 1) == -1)
				{
					fprintf(stderr, "Failed to write to pipe");
					exit(1);
				}	
				
			}
			if(in == pipeC2P[0])
			{
				if(write(out, &crlf, 1) == -1)
				{	
					fprintf(stderr, "Failed to write bits to %d: %s",out, strerror(errno));
					exit(1);
				
				}
			
			}
		
		}*/
		else
		{
			if(encryptFlag == 1 && in == pipeC2P[0])
			{
				encrypt(buf + readCount, 1, iv, key, keyLen);
			}
			if(in == pipeC2P[0])
			{
				if(write(out, buf + readCount, 1) == -1)
				{
					fprintf(stderr, "Failed to write bits to %d: %s",out, strerror(errno));
					exit(1);
				}
			}
			else if(in == connection)
			{
				if(write(pipeP2C[1], buf + readCount, 1) == -1)
				{
					fprintf(stderr, "failed to write to pipe");
					exit(1);
				} 
			}
		}
		
		readCount++;
	}
	if(readSuccess == 0)
	{
		close(socketfd);
		close(connection);
		kill(childPID, SIGTERM);
		clientExit = 1;
	}
	if(readSuccess == -1)
	{
		if(in == connection)
		{
			clientExit = 1;		
		}
		else if(in == pipeC2P[0])
		{
			shellExit = 1;
		}
	//	fprintf(stderr, "Failure to read bits from %d: %s", in, strerror(errno));
//		exit(1);
	}
}

int main(int argc, char** argv)
{
	//if(argv[1] != 's')
	//{
	//	fprintf(stderr, "Too many arguments %s %s %s", argv[0], argv[1], argv[2]);

	//	exit(1);
	//}
	buf = (char*)malloc(sizeof(char) * 1024);
	if(*buf == -1)
	{
		fprintf(stderr, "Error while using malloc\n");
		exit(1);
	}
	static struct option args[] =
	{
		{"port", required_argument, 0, 'p'},
		{"encrypt", required_argument, 0, 'e'},
		{0,0,0,0}	
	
	};
	//if(!isatty(0))
	//{
//		fprintf(stderr, "Invalid input"
//	}
	int option = 0;

	while((option = getopt_long(argc,argv, "p:e", args, NULL)) != -1)
	{
		switch(option)
		{
			case 'p':
				portNum = atoi(optarg);
				break;
			case 'e':
				encryptFlag = 1;
				keyfd = open(optarg, O_RDONLY, 0);
				if(keyfd == -1)
				{
					fprintf(stderr, "Couldn't open key file");
					exit(1);
				}
				char keyBuf[17];
				int keyBytesRead = read(keyfd, keyBuf, 16);
				if(keyBytesRead == -1)
				{
					fprintf(stderr, "Failed to read from key file");
					exit(1);
				}
				else if(keyBytesRead  < 16)
				{
					fprintf(stderr, "Key too small. Must be 16 bytes");
					exit(1);
				}
				keyBuf[16] = '\0';
				key = (char *) &keyBuf;
				break;
			default:
				fprintf(stderr, "Correct flags are --poll=# greater than 1024, --encrypt=\"key\"\n");
				exit(1);
		}
	}
	if(portNum > 1024)
	{
	//	signal(SIGTTIN, signalOutput);
		struct sockaddr_in server;
		struct sockaddr_in client;
		socketfd = socket(AF_INET, SOCK_STREAM,0);
		if(socketfd == -1)
		{
			fprintf(stderr,"Failed to create socket to port.");
			exit(1);
		}
		memset((char*) &server,0, sizeof(server));
		
		server.sin_family = AF_INET;
		server.sin_addr.s_addr = INADDR_ANY;
		server.sin_port = htons(portNum);

		if(bind(socketfd, (struct sockaddr *) &server, sizeof(server)) < 0)
		{
			fprintf(stderr, "Failed during bind to socket");
			exit(1);
		}

		listen(socketfd, 2);
		socklen_t sizeOfClient = sizeof(client);
		connection = accept(socketfd, (struct sockaddr *)&client, &sizeOfClient);
		if(connection < 0)
		{
			fprintf(stderr, "Failed during accept");
			exit(1);
		}
		//while(1)
		//{
		//	passBytes(connection, 1);
		//}
		
			 if(pipe(pipeP2C) == -1)
			{
				fprintf(stderr, "Fail while calling pipe()");
				exit(1);
			}
			if(pipe(pipeC2P) == -1)
			{
				fprintf(stderr, "Fail while calling pipe()");
				exit(1);
			}
			
			pollArr[0] = (struct pollfd){.fd = connection, .events = POLLIN};
			pollArr[1] = (struct pollfd) {.fd = pipeC2P[0], .events = POLLIN};
			childPID = fork();
			if(childPID == -1)
			{
				
				fprintf(stderr, "Failed to fork");
				exit(1);
			}
			else if(childPID == 0)	//child
			{
				
				close(pipeP2C[1]);		//close write of parent to child pipe
				close(pipeC2P[0]);		//close read of child to parent pipe
				close(0);	
				dup(pipeP2C[0]);
				close(1);
				dup(pipeC2P[1]);
				close(2);
				dup(pipeC2P[1]);
				close(pipeP2C[0]);
				close(pipeP2C[1]);
				char *bashArgs[] = {"/bin/bash", NULL};
				if(execvp("/bin/bash",bashArgs) == -1)
				{
					fprintf(stderr, "Couldn't execute /bin/bash: %s", strerror(errno));
					exit(1);
				}
				//while(1)
				//{
				//	passBytes(0, 1);
				//}
				
			}	
			else					//parent
			{
			
				close(pipeP2C[0]);
				close(pipeC2P[1]);
				//pass from shell program to output			
				//wait(childPID);
				poll(pollArr, 2, 0);
				clientExit = 0;
				shellExit = 0;
				while(1)
				{
					if(pollArr[0].revents == POLLIN)
					{
						passBytes(connection,1);
						poll(pollArr,2,0);
					}
					if(pollArr[1].revents ==POLLIN)
					{
						passBytes(pipeC2P[0], connection);
						poll(pollArr,2,0);
					}
					if(clientExit ==1 || shellExit == 1)
					{
						close(connection);	
						int exitStatus;
						waitpid(childPID, &exitStatus,0);
						
						//if(WIFSIGNALED(exitStatus))
						//{
						//	fprintf(stderr, "ended by signal, %d %d", exitStatus, &exitStatus);
						//}
						//if(WIFEXITED(exitStatus))
						//{					
						//f(WIFSIGNALED(exitStatus));
						int low = WEXITSTATUS(exitStatus);
						int high;
						if(WIFSIGNALED(exitStatus))
						{
							high = WTERMSIG(exitStatus);	
						}
						else
						{
							high = 0;
						}
					//	fprintf(stderr, "regular exit");
						fprintf(stderr, "SHELL EXIT SIGNAL=%d  STATUS=%d", high, low);
						
						exit(0);
										
					}
				/* 	if(pollArr[0].revents == POLLIN && pipeClosed != 2)
					{
						passBytes(connection,1);
						//write(1,buffer, strlen(&buffer));
						if(pipeClosed != 2)
						{
							passBytes(pipeC2P[0], 1);//passBytes(pipeC2P[0], 1);
						}
						
					} */
					if(pollArr[1].revents == POLLHUP || pollArr[1].revents == POLLERR)
					{
						close(pipeP2C[0]);
						close(pipeP2C[1]);
						close(pipeC2P[0]);
						close(pipeC2P[1]);
						close(connection);
						close(socketfd);	
						int exitStatus;
						waitpid(childPID, &exitStatus,0);
						
						//if(WIFSIGNALED(exitStatus))
						//{
						//	fprintf(stderr, "ended by signal, %d %d", exitStatus, &exitStatus);
						//}
						//if(WIFEXITED(exitStatus))
						//{					
						//f(WIFSIGNALED(exitStatus));
						int low = WEXITSTATUS(exitStatus);
						int high;
						if(WIFSIGNALED(exitStatus))
						{
							high = WTERMSIG(exitStatus);	
						}
						else
						{
							high = 0;
						}
						//fprintf(stderr,"pollup");
						fprintf(stderr, "SHELL EXIT SIGNAL=%d  STATUS=%d", high, low);
						exit(0);
					}
					poll(pollArr,2,0);
				}
			} 

			
	}
	else
	{
		fprintf(stderr, "Poll number too low; must be greater than 1024.");
		exit(1);
	}
	exit(0);
	
}

//NAME:Connor Borden
//EMAIL:connorbo97@g.ucla.edu
//ID:004603469

#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <getopt.h>
#include <string.h>
#include <errno.h>
#include <poll.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <mcrypt.h>
#include <sys/stat.h>

int pipeP2C[2];
int pipeC2P[2];
char* buf;
int bufferLen = 16;
int keyLen = 16;
pid_t childPID;
struct pollfd pollArr[2];
//pid_t parentPID;
int socketfd;
int portNum;
int socketClosed;
int multipleZeroReadFromSocket = 0;
int logfd = -1;
MCRYPT crypt1;
MCRYPT crypt2;
char* iv = "AAAAAAAAAAAAAAAA";
char* key;
int encryptFlag = 0;
int keyfd;

int checkIsFile(const char *check)
{
	struct stat path;
	stat(check, &path);
	return S_ISREG(path.st_mode);
}
void restoreTerminal()
{
	struct termios restorer;
	tcgetattr(0, &restorer);
	restorer.c_iflag = 1280;
	restorer.c_lflag = 35387;
	restorer.c_oflag = 5;
	tcsetattr(0, TCSANOW, &restorer);
}

void signalOutput(int signal)
{
	
//			char buffer[6] = "p";
//			write(1,buffer, strlen(&buffer));
	restoreTerminal();
	if(signal == SIGINT)
	{
		fprintf(stdout, "SIGINT recieved");
		//	restoreTerminal();
		exit(1);
		
	}
	else
	{
		exit(2);
	}
	//exit(1);
}

void encrypt(char* buffer, int buffer_len, char* IV, char* key1, int key_len)
{
	crypt1 = mcrypt_module_open("twofish", NULL, "cfb", NULL);
	//int block = mcrypt_enc_get_block_size(crypt1);
	/*if(buffer_len % block != 0)
	{
		fprintf(stderr, "incompatible block size");
		exit(1);
	}*/
	
	mcrypt_generic_init(crypt1, key1, key_len, IV);
	mcrypt_generic(crypt1, buffer, buffer_len);
	mcrypt_generic_deinit(crypt1);
	mcrypt_module_close(crypt1);
}

void decrypt(void* buffer, int buffer_len, char* IV, char* key1, int key_len)
{
	crypt2 = mcrypt_module_open("twofish", NULL, "cfb", NULL);
	mcrypt_generic_init(crypt2, key1, key_len, IV);
	mdecrypt_generic(crypt2, buffer, buffer_len);
	mcrypt_generic_deinit(crypt2);
	mcrypt_module_close(crypt2);
}

void passBytes(int in, int out)
{
	//fprintf(stderr, "pb");
	int readSuccess = read(in, buf, 1024);
	int readCount = 0;
	if(readSuccess > readCount)
	{
		char numBytes[5];
		int technicalTotal = readSuccess;
		int i;
		for(i = 0; i < readSuccess; i++)
		{
			if(*(buf + i) == '\r' || *(buf + i) == '\n')
			{
				technicalTotal++;
			}
		}
		sprintf(numBytes, "%d", technicalTotal);
		
		if(logfd > -1)
		{
			if(in == 0)
			{
				char message[25] = "SENT ";
				strcat(message, numBytes);
				strcat(message, " BYTES: ");
				if(write(logfd, &message, strlen(message))== -1)
				{
					fprintf(stderr, "failed to write to log file");
					restoreTerminal();
					exit(1);
				}
			}
			else
			{
				char message[25] = "RECEIVED ";
				strcat(message, numBytes);
				strcat(message, " BYTES: ");
				if(write(logfd, &message, strlen(message)) == -1)
				{
					fprintf(stderr, "failed to write to log file");
					restoreTerminal();
					exit(1);
				}
				
			}		
		}
	}
	while(readSuccess > readCount)
	{	
		if(encryptFlag == 1 && in == socketfd)
		{
			if(write(logfd, buf + readCount, 1) == -1)
			{
				fprintf(stderr, "failed to write to log");
				exit(1);
			}
			decrypt(buf + readCount, 1, iv, key, keyLen);
		}
		if((*(buf+readCount) == '\r' || *(buf+readCount) == '\n'))
		{
			//close(socketfd);
			char cr = '\r';
			char lf = '\n';
			//crlf[0] = '\r';
			//crlf[1] = '\n';
			//*buf = '\015';
			//write(out, buf, 1);
			//*buf = '\012';
			
			if(in == 0)
			{
				if(write(1, &cr, 1) == -1)
				{
					fprintf(stderr, "Failed to write bits to stdout");
					restoreTerminal();
					exit(1);
				}
				if(write(1, &lf, 1) == -1)
				{
					fprintf(stderr, "Failed to write bits to stdout");
					restoreTerminal();
					exit(1);
				}
			}	
			if(encryptFlag == 1 && in == 0)
			{
				encrypt(&cr, 1, iv, key, keyLen); 
				encrypt(&lf, 1, iv, key, keyLen);
			}
			if(in == socketfd)
			{
				if(write(out, &cr, 1) == -1)
				{
					fprintf(stderr, "Failed to write bits to %d: %s", out, strerror(errno));
					restoreTerminal();
					exit(1);
				}
			}
					
			if(write(out, &lf, 1) == -1)
			{	
				fprintf(stderr, "Failed to write bits to %d: %s",out, strerror(errno));
				restoreTerminal();
				exit(1);
				//break;
			}
			if(logfd > -1 && ((encryptFlag == 0) || (encryptFlag == 1 && in == 0)))
			{
				char crlf[2];
				crlf[0] = cr;
				crlf[1] = lf;
				if(write(logfd, &crlf, 2)== -1)
				{
					fprintf(stderr, "failed to write to log");
					exit(1);
				}

				
			}
		
		}
		else
		{
			if(in == 0)
			{
				if(write(1, buf + readCount, 1) == -1)
				{
					fprintf(stderr, "Failed to write bits to stdout");
					restoreTerminal();
					exit(1);
				}
			}
			if(encryptFlag == 1)
			{
				if(in == 0)
				{
					encrypt(buf + readCount, 1, iv, key, keyLen);
				}
			}
			
			if(write(out, buf + readCount, 1) == -1)
			{
				fprintf(stderr, "Failed to write bits to %d: %s",out, strerror(errno));
				exit(1);
			}
			if(logfd > -1 && ((encryptFlag == 0) || (encryptFlag == 1 && in == 0)))
			{
				if(write(logfd, buf + readCount, 1) == -1)
				{
					fprintf(stderr, "failed to write to log");
					exit(1);
				}
			}
		}
		
		readCount++;
	
	}
	if(readSuccess > 0)
	{
		if(logfd > -1)
		{
			char nl = '\n';
			if(write(logfd, &nl, 1) == -1)
			{
				fprintf(stderr, "failed to print to log");
				restoreTerminal();
				exit(1);
			}
		}
	}
	if(readSuccess == 0 && in == socketfd)
	{
		multipleZeroReadFromSocket++;
		if(multipleZeroReadFromSocket == 3)
		{
			restoreTerminal();
			exit(0);
		}
	}
	if(readSuccess == -1)
	{
		fprintf(stderr, "failure");
		if(in == socketfd)
		{
			socketClosed = 1;
		}
		else
		{
			fprintf(stderr, "Failure to read bits from %d: %s", in, strerror(errno));
			exit(1);
		}
	}
}

int main(int argc, char** argv)
{
	//if(argv[1] != 's')
	//{
	//	fprintf(stderr, "Too many arguments %s %s %s", argv[0], argv[1], argv[2]);

	//	exit(1);
	//}
	buf = (char*)malloc(sizeof(char) * 1024);
	if(*buf == -1)
	{
		fprintf(stderr, "Error while using malloc\n");
		exit(1);
	}
	if(!isatty(0))
	{
		fprintf(stderr, "Not a terminal \n");
		exit(1);
	}
	static struct option args[] =
	{
		{"port", required_argument, 0, 'p'},
		{"log", required_argument, 0, 'l'},
		{"encrypt", required_argument, 0, 'e'},
		{0,0,0,0}	
	
	};
	//if(!isatty(0))
	//{
//		fprintf(stderr, "Invalid input"
//	}
	int option = 0;

	mode_t perm = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
	while((option = getopt_long(argc,argv, "p:l:e", args, NULL)) != -1)
	{
		switch(option)
		{
			case 'p':
				portNum = atoi(optarg);
				break;
			case 'l':
				logfd = open(optarg, O_WRONLY | O_CREAT| O_TRUNC, perm);
				if(logfd == -1)
				{
					if(checkIsFile(optarg) == 0)
					{
						fprintf(stderr, "Not a regular file");
						exit(1);
					}
					if(access(optarg, W_OK) == -1)
					{
						fprintf(stderr, "Log file not writable");
						
						exit(1);
					}
					fprintf(stderr, "Couldn't open log file");
					exit(1);
				}
				break;
			case 'e':
				encryptFlag = 1;
				keyfd = open(optarg, O_RDONLY, 0);
				if(keyfd == -1)
				{
					fprintf(stderr, "Couldn't open key file");
					exit(1);
				}
				char keyBuf[17];
				int keyBytesRead = read(keyfd, keyBuf, 16);
				if(keyBytesRead == -1)
				{
					fprintf(stderr, "Failed to read from key file");
					exit(1);
				}
				else if(keyBytesRead  < 16)
				{
					fprintf(stderr, "Key too small. Must be 16 bytes");
					exit(1);
				}
				keyBuf[16] = '\0';
				key = (char *) &keyBuf;
				
				break;
				
			default:
				fprintf(stderr, "Correct flags are --poll=# greater than 1024, --log=FILE, or --encrypt=FILE to be used as key, should be same as server argument");
				exit(1);
		}
	}
	
	struct termios a;
	if(tcgetattr(0, &a) < 0)
	{	
		fprintf(stderr, "errno: %d\n", errno);
		fprintf(stderr, "Failed while getting terminal: %s\n", strerror(errno));
		restoreTerminal();
		exit(1);
	}
	a.c_iflag = ISTRIP;
	a.c_lflag = 0;
	a.c_oflag = 0;
	//printf("iflag %d oflag %d cflag %d lflag %d \n", a.c_iflag, a.c_oflag, a.c_cflag, a.c_lflag);
	
	if(tcsetattr(0,TCSAFLUSH, &a) < 0)
	{
		fprintf(stderr, "failed while setting terminal attributes, errno: %d str: %s\n", errno, strerror(errno));
			restoreTerminal();
		exit(1);
	}
	if(portNum > 1024)
	{
		struct sockaddr_in server;
		socketfd = socket(AF_INET, SOCK_STREAM, 0);
		struct hostent *host;
	
		if(socketfd == -1)
		{
			fprintf(stderr,"Failed to create socket to port.");
			restoreTerminal();
			exit(1);
		}
		host = gethostbyname("localhost");
		if(host == NULL)
		{
			fprintf(stderr, "Error, no such host");
			exit(1);
		}
		memset((char*)&server,0, sizeof(server));
		server.sin_family = AF_INET;
		memcpy((char *)host->h_addr, (char *)&server.sin_addr.s_addr, host->h_length);
		server.sin_port = htons(portNum);

		if(connect(socketfd, (struct sockaddr*)&server, sizeof(server)) < 0)
		{
			fprintf(stderr, "Failed to connect to server");
			restoreTerminal();
			exit(1);
		}
		
		pollArr[0] = (struct pollfd){.fd =0, .events = POLLIN};
		pollArr[1] = (struct pollfd) {.fd = socketfd, .events = POLLIN};
		
		//poll(pollArr,2,0);
		while(1)
		{
			poll(pollArr,2,0);
			if(socketClosed > 0)
			{
			//	fprintf(stderr,"socket");		
				restoreTerminal();
				exit(0);
										
			}
			if(pollArr[0].revents == POLLIN)
			{
				passBytes(0,socketfd);
				poll(pollArr,2,0);			
			}
			if(pollArr[1].revents == POLLIN)
			{
				passBytes(socketfd,1);
				poll(pollArr,2,0);
			}
			if(pollArr[1].revents == POLLHUP || pollArr[1].revents == POLLERR)
			{
				restoreTerminal();
				exit(0);			
			}
		} 

			
	}
	else
	{
		fprintf(stderr, "Poll number too low; must be greater than 1024.");
		exit(1);
	}
	restoreTerminal();
	exit(0);
	
}
